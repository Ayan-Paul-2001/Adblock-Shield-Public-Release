(function() {
  const noop = function() {};
  const AdsLoader = function() { this._listeners = {}; };
  AdsLoader.prototype.addEventListener = function(type, cb) { this._listeners[type] = cb; };
  AdsLoader.prototype.removeEventListener = noop;
  AdsLoader.prototype.contentComplete = noop;
  AdsLoader.prototype.destroy = noop;
  AdsLoader.prototype.getSettings = function() {
    return {
      setAutoPlayAdBreaks: noop,
      setCookiesEnabled: noop,
      setDisableCustomPlaybackForIOS10Plus: noop,
      setLocale: noop,
      setNumRedirects: noop,
      setPlayerType: noop,
      setPlayerVersion: noop,
      setPpid: noop,
      setSessionId: noop,
      setVpaidAllowed: noop,
      setVpaidMode: noop
    };
  };
  AdsLoader.prototype.requestAds = function() {
    const self = this;
    setTimeout(function() {
      const errCb = self._listeners['adError'] || self._listeners['adsManagerLoaded'];
      if (typeof errCb === 'function') {
        try {
          errCb({
            getError: function() {
              return {
                getErrorCode: function() { return 1009; },
                getMessage: function() { return 'The VAST response document is empty.'; },
                getType: function() { return 'adPlayError'; }
              };
            },
            getAdsManager: function() {
              return {
                addEventListener: noop,
                removeEventListener: noop,
                init: noop,
                start: noop,
                stop: noop,
                destroy: noop,
                resize: noop,
                pause: noop,
                resume: noop,
                setVolume: noop,
                getVolume: function() { return 0; },
                getRemainingTime: function() { return 0; }
              };
            }
          });
        } catch (_) {}
      }
    }, 1);
  };

  window.google = window.google || {};
  window.google.ima = {
    AdDisplayContainer: function() { this.initialize = noop; this.destroy = noop; },
    AdError: { Type: {}, ErrorCode: {} },
    AdErrorEvent: { Type: { AD_ERROR: 'adError' } },
    AdEvent: {
      Type: {
        ALL_ADS_COMPLETED: 'allAdsCompleted',
        CLICK: 'click',
        COMPLETE: 'complete',
        CONTENT_PAUSE_REQUESTED: 'contentPauseRequested',
        CONTENT_RESUME_REQUESTED: 'contentResumeRequested',
        FIRST_QUARTILE: 'firstQuartile',
        LOADED: 'loaded',
        MIDPOINT: 'midpoint',
        PAUSED: 'paused',
        RESUMED: 'resumed',
        SKIPPED: 'skipped',
        STARTED: 'started',
        THIRD_QUARTILE: 'thirdQuartile'
      }
    },
    AdsLoader: AdsLoader,
    AdsManager: function() {},
    AdsManagerLoadedEvent: { Type: { ADS_MANAGER_LOADED: 'adsManagerLoaded' } },
    AdsRenderingSettings: function() {},
    AdsRequest: function() {
      this.setAdWillAutoPlay = noop;
      this.setAdWillPlayMuted = noop;
      this.setContinuousPlayback = noop;
    },
    CompanionAdSelectionSettings: { CreativeType: {}, ResourceType: {}, SizeCriteria: {} },
    ImaSdkSettings: { VpaidMode: { DISABLED: 0, ENABLED: 1, INSECURE: 2 } },
    OmidAccessMode: { FULL: 'full', DOMAIN: 'domain', LIMITED: 'limited' },
    settings: { setLocale: noop, setVpaidMode: noop, setDisableCustomPlaybackForIOS10Plus: noop },
    UiElements: { AD_ATTRIBUTION: 'adAttribution', COUNTDOWN: 'countdown' },
    UniversalAdIdInfo: function() {},
    ViewMode: { FULLSCREEN: 'fullscreen', NORMAL: 'normal' }
  };
})();

