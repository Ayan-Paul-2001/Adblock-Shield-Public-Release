window.COMSCORE = { beacon: function() {}, purge: function() { return []; } };
window._comscore = window._comscore || [];

