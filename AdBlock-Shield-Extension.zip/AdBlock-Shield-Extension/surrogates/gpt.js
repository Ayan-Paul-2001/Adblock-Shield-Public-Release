(function() {
  const noop = function() {};
  const noopThis = function() { return this; };
  const noopNull = function() { return null; };
  const noopArr = function() { return []; };
  const noopFalse = function() { return false; };
  const noopStr = function() { return ''; };

  const slotObj = {
    addService: noopThis,
    clearCategoryExclusions: noopThis,
    clearTargeting: noopThis,
    defineSizeMapping: noopThis,
    get: noopNull,
    getAdUnitPath: noopStr,
    getAttributeKeys: noopArr,
    getCategoryExclusions: noopArr,
    getDomId: noopStr,
    getResponseInformation: noopNull,
    getSlotElementId: noopStr,
    getSlotId: noopThis,
    getTargeting: noopArr,
    getTargetingKeys: noopArr,
    set: noopThis,
    setCategoryExclusion: noopThis,
    setClickUrl: noopThis,
    setCollapseEmptyDiv: noopThis,
    setForceSafeFrame: noopThis,
    setSafeFrameConfig: noopThis,
    setTargeting: noopThis
  };

  const pubadsObj = {
    addEventListener: noopThis,
    clear: noop,
    clearCategoryExclusions: noopThis,
    clearTagForChildDirectedTreatment: noopThis,
    clearTargeting: noopThis,
    collapseEmptyDivs: noop,
    defineOutOfPagePassback: function() { return slotObj; },
    definePassback: function() { return slotObj; },
    disableInitialLoad: noop,
    display: noop,
    enableAsyncRendering: noop,
    enableLazyLoad: noop,
    enableSingleRequest: noop,
    enableSyncRendering: noop,
    enableVideoAds: noop,
    get: noopNull,
    getAttributeKeys: noopArr,
    getSlots: noopArr,
    getSlotIdMap: function() { return {}; },
    getTargeting: noopArr,
    getTargetingKeys: noopArr,
    isInitialLoadDisabled: noopFalse,
    refresh: noop,
    removeEventListener: noopFalse,
    set: noopThis,
    setCategoryExclusion: noopThis,
    setCentering: noop,
    setCookieOptions: noopThis,
    setForceSafeFrame: noopThis,
    setLocation: noopThis,
    setPrivacySettings: noopThis,
    setPublisherProvidedId: noopThis,
    setRequestNonPersonalizedAds: noopThis,
    setSafeFrameConfig: noopThis,
    setTagForChildDirectedTreatment: noopThis,
    setTagForUnderAgeOfConsent: noopThis,
    setTargeting: noopThis,
    setVideoContent: noopThis,
    updateCorrelator: noop
  };

  const gt = window.googletag || {};
  const cmd = gt.cmd || [];
  cmd.push = function(fn) {
    if (typeof fn === 'function') {
      try { fn(); } catch (_) {}
    }
    return 1;
  };
  gt.cmd = cmd;
  gt.apiReady = true;
  gt.pubadsReady = true;
  gt.companionAds = function() { return pubadsObj; };
  gt.content = function() { return pubadsObj; };
  gt.defineOutOfPageSlot = function() { return slotObj; };
  gt.defineSlot = function() { return slotObj; };
  gt.defineUnit = function() { return slotObj; };
  gt.destroySlots = noop;
  gt.disablePublisherConsole = noop;
  gt.display = noop;
  gt.enableServices = noop;
  gt.getVersion = noopStr;
  gt.pubads = function() { return pubadsObj; };
  gt.setAdIframeTitle = noop;
  gt.sizeMapping = function() { return { addSize: noopThis, build: noopNull }; };
  window.googletag = gt;
  while (cmd.length > 0) {
    const fn = cmd.shift();
    if (typeof fn === 'function') {
      try { fn(); } catch (_) {}
    }
  }
})();

