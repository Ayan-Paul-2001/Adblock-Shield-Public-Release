/**
 * AdBlock Shield Pro V2.0.1 — ISOLATED World Content Script (Runs at document_start)
 *
 * Responsibilities:
 * 1. Injects Brave's high-precision Cosmetic Filtering CSS rules into every page
 *    while respecting Brave's `youtube.com#@#.video-ads` anti-adblock bait exception.
 * 2. Blacks out `.ad-showing` video frames on YouTube so skipped ads are never seen.
 * 3. Bridges telemetry events from `content-main.js` (MAIN world) to `background.js`.
 */

(function () {
  'use strict';

  const hostname = (location.hostname || '').replace(/^www\./, '').toLowerCase();
  const isYoutube = /(^|\.)youtube\.com$|(^|\.)youtubekids\.com$/i.test(hostname);

  const GENERAL_COSMETIC_CSS = `
    /* AdBlock Shield Pro — Brave Cosmetic Filtering Engine */
    ins.adsbygoogle,
    div[id^="google_ads_iframe_"],
    div[id^="div-gpt-ad"],
    iframe[id^="google_ads_frame"],
    iframe[src*="doubleclick.net"],
    iframe[src*="googlesyndication.com"],
    iframe[src*="adsterra"],
    iframe[src*="propellerads"],
    iframe[src*="exoclick"],
    iframe[src*="clickadu"],
    [class*="taboola-"],
    [id*="taboola-"],
    .OUTBRAIN,
    [data-ob-template],
    [id^="mgid_"],
    .mgbox,
    div[class*="ad-container"]:not(#movie_player *),
    div[class*="ad_wrapper"]:not(#movie_player *),
    div[id*="sticky-ad"],
    a[href*="krikya"],
    a[href*="1xbet"],
    a[href*="melbet"],
    a[href*="mostbet"],
    a[href*="baji.live"],
    a[href*="onclkds.com"] {
      display: none !important;
      visibility: hidden !important;
      height: 0 !important;
      min-height: 0 !important;
      max-height: 0 !important;
      overflow: hidden !important;
      pointer-events: none !important;
    }
  `;

  // Note: Brave intentionally un-hides `.video-ads` on YouTube (`youtube.com#@#.video-ads`)
  // so YouTube's anti-adblock offsetHeight check passes, while hiding actual ad renderers
  // and blacking out the video frame during `.ad-showing` while it fast-forwards.
  const YOUTUBE_COSMETIC_CSS = `
    /* Brave YouTube Cosmetic Rules (Preserves .video-ads bait check) */
    ytd-ad-slot-renderer,
    ytd-in-feed-ad-layout-renderer,
    ytd-banner-promo-renderer,
    ytd-statement-banner-renderer,
    ytd-display-ad-renderer,
    ytd-promoted-sparkles-web-renderer,
    ytd-promoted-sparkles-text-search-renderer,
    ytd-promoted-video-renderer,
    ytd-compact-promoted-video-renderer,
    ytd-player-legacy-desktop-watch-ads-renderer,
    ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"],
    ytd-merch-shelf-renderer,
    ytm-promoted-sparkles-web-renderer,
    ytm-companion-ad-renderer,
    #masthead-ad,
    #player-ads,
    #panels > ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"],
    .ytp-ad-overlay-container,
    .ytp-ad-message-container,
    .ytp-ad-image-overlay,
    .ytp-ad-text-overlay,
    .ytp-ad-action-interstitial,
    ytd-enforcement-message-view-model {
      display: none !important;
      visibility: hidden !important;
      height: 0 !important;
      pointer-events: none !important;
    }

    /* Hide ad video frames & ad overlay UI during instant fast-forward */
    .html5-video-player.ad-showing video.html5-main-video,
    .html5-video-player.ad-interrupting video.html5-main-video,
    .html5-video-player.ad-showing .ytp-ad-player-overlay,
    .html5-video-player.ad-showing .ytp-ad-player-overlay-layout {
      opacity: 0 !important;
    }
  `;

  let styleElement = null;

  function applyCosmeticShield(enabled) {
    if (!enabled) {
      if (styleElement && styleElement.parentNode) {
        styleElement.remove();
        styleElement = null;
      }
      return;
    }

    if (!styleElement) {
      styleElement = document.createElement('style');
      styleElement.id = 'adblock-shield-pro-cosmetics';
      styleElement.textContent =
        GENERAL_COSMETIC_CSS + (isYoutube ? YOUTUBE_COSMETIC_CSS : '');
      (document.head || document.documentElement).appendChild(styleElement);
    } else if (
      !styleElement.parentNode &&
      (document.head || document.documentElement)
    ) {
      (document.head || document.documentElement).appendChild(styleElement);
    }
  }

  function syncWithBackground() {
    try {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (res) => {
        if (chrome.runtime.lastError || !res || !res.ok) return;
        const st = res.state || {};
        const isSiteWhitelisted =
          Array.isArray(st.whitelistedSites) &&
          st.whitelistedSites.includes(hostname);
        const activeOnSite = Boolean(st.enabled) && !isSiteWhitelisted;

        applyCosmeticShield(activeOnSite && st.cosmeticFiltering !== false);

        window.postMessage(
          {
            __adblockShieldType: 'CONFIG_SYNC',
            payload: {
              enabled: activeOnSite,
              aggressiveYoutubeShield: st.aggressiveYoutubeShield !== false,
              blockPopundersAndRedirects:
                st.blockPopundersAndRedirects !== false
            }
          },
          '*'
        );
      });
    } catch (_) {}
  }

  syncWithBackground();

  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(() => {
      syncWithBackground();
    });
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;
    if (event.data.__adblockShieldType === 'BLOCK_EVENT' && event.data.payload) {
      try {
        chrome.runtime.sendMessage({
          type: 'CONTENT_BLOCK_EVENT',
          ...event.data.payload
        });
      } catch (_) {}
    }
  });
})();
