/**
 * AdBlock Shield Pro V2.0.1 — Background Service Worker (Manifest V3)
 *
 * Features:
 * 1. "Always On When Browser Opens" (alwaysOnStartup):
 *    Automatically forces Shield protection ON at browser startup (chrome.runtime.onStartup),
 *    extension install/update (chrome.runtime.onInstalled), and periodic watchdog alarm.
 * 2. Brave Engine Static & Dynamic DeclarativeNetRequest (DNR) Management:
 *    Controls 4 static rulesets (Brave Ads, Privacy Trackers, Clean URLs, Surrogates)
 *    plus dynamic custom rules and per-site whitelist exceptions.
 * 3. Real-Time Telemetry & Per-Tab Badge Counter:
 *    Tracks blocked ads/trackers, YouTube ads skipped, cosmetic elements hidden,
 *    popunders neutralized, and estimated bandwidth saved.
 * 4. Silent OTA Auto-Update Engine:
 *    Checks remote version manifest and syncs updated rules without exposing repo URLs.
 */

const STATIC_RULESETS = [
  'ruleset_brave_ads',
  'ruleset_privacy_trackers',
  'ruleset_clean_urls',
  'ruleset_surrogates'
];

// Remote OTA endpoint (kept strictly internal, never displayed in UI)
const OTA_MANIFEST_URL =
  'https://raw.githubusercontent.com/Ayan-Paul-2001/Adblock-Shield-Public-Release/main/version.json';

const DEFAULT_STATE = {
  enabled: true,
  alwaysOnStartup: true,
  aggressiveYoutubeShield: true,
  blockPopundersAndRedirects: true,
  stripTrackingParams: true,
  cnameUncloaking: true,
  antiFingerprinting: true,
  cosmeticFiltering: true,
  autoUpdateEnabled: true,
  version: '2.0.1',
  definitionsBuild: '2026.10.31.2010',
  lastUpdated: new Date().toLocaleString(),
  updateAvailable: false,
  latestRemoteVersion: '2.0.1',
  latestReleaseNotes: 'Brave Shields MV3 Engine + YouTube SABR Patch + 3D Three.js Control Center',
  whitelistedSites: [],
  customBlockedDomains: [
    'krikya11.live',
    'krikya.live',
    '1xbet.com',
    'melbet.com',
    'mostbet.com',
    'baji.live',
    'adsterra.com',
    'propellerads.com'
  ],
  stats: {
    totalBlocked: 0,
    youtubeAdsSkipped: 0,
    trackersBlocked: 0,
    popundersBlocked: 0,
    cosmeticHidden: 0,
    bytesSaved: 0
  },
  activityLog: []
};

// Per-tab blocked counters in memory
const tabBlockCounts = new Map();

/**
 * Load state from chrome.storage.local, merging defaults safely
 */
async function getState() {
  const stored = await chrome.storage.local.get(null);
  return {
    ...DEFAULT_STATE,
    ...stored,
    stats: {
      ...DEFAULT_STATE.stats,
      ...(stored.stats || {})
    },
    whitelistedSites: Array.isArray(stored.whitelistedSites)
      ? stored.whitelistedSites
      : DEFAULT_STATE.whitelistedSites,
    customBlockedDomains: Array.isArray(stored.customBlockedDomains)
      ? stored.customBlockedDomains
      : DEFAULT_STATE.customBlockedDomains,
    activityLog: Array.isArray(stored.activityLog)
      ? stored.activityLog
      : DEFAULT_STATE.activityLog
  };
}

/**
 * Save partial state updates to chrome.storage.local
 */
async function saveState(patch) {
  await chrome.storage.local.set(patch);
}

/**
 * Synchronize DeclarativeNetRequest static & dynamic rulesets with current state
 */
async function syncProtectionEngine(stateOverride = null) {
  const state = stateOverride || (await getState());

  try {
    if (state.enabled) {
      const enableIds = ['ruleset_brave_ads', 'ruleset_surrogates'];
      const disableIds = [];

      if (state.cnameUncloaking !== false) {
        enableIds.push('ruleset_privacy_trackers');
      } else {
        disableIds.push('ruleset_privacy_trackers');
      }

      if (state.stripTrackingParams !== false) {
        enableIds.push('ruleset_clean_urls');
      } else {
        disableIds.push('ruleset_clean_urls');
      }

      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: enableIds,
        disableRulesetIds: disableIds
      });
    } else {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: [],
        disableRulesetIds: STATIC_RULESETS
      });
    }

    // Rebuild dynamic rules (custom blocked domains + whitelisted site exceptions)
    const existingDynamic = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = existingDynamic.map((r) => r.id);
    const addRules = [];

    if (state.enabled) {
      let nextId = 10000;

      // 1. Whitelisted sites get high-priority allowAllRequests rules
      for (const site of state.whitelistedSites) {
        const cleanSite = String(site || '').trim().toLowerCase();
        if (!cleanSite) continue;
        addRules.push({
          id: nextId++,
          priority: 10000,
          action: { type: 'allowAllRequests' },
          condition: {
            requestDomains: [cleanSite],
            resourceTypes: ['main_frame', 'sub_frame']
          }
        });
        addRules.push({
          id: nextId++,
          priority: 10000,
          action: { type: 'allow' },
          condition: {
            initiatorDomains: [cleanSite]
          }
        });
      }

      // 2. Custom blocked domains get high-priority block rules
      for (const domain of state.customBlockedDomains) {
        const cleanDomain = String(domain || '')
          .trim()
          .toLowerCase()
          .replace(/^https?:\/\//, '')
          .replace(/\/.*$/, '');
        if (!cleanDomain) continue;
        addRules.push({
          id: nextId++,
          priority: 500,
          action: { type: 'block' },
          condition: {
            urlFilter: `||${cleanDomain}^`,
            resourceTypes: [
              'main_frame',
              'sub_frame',
              'script',
              'image',
              'xmlhttprequest',
              'media',
              'ping',
              'websocket',
              'other'
            ]
          }
        });
      }
    }

    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds,
      addRules
    });
  } catch (err) {
    console.warn('[AdBlock Shield Pro] DNR sync warning:', err);
  }

  await updateBadgeForActiveTab(state);
}

/**
 * Update toolbar badge color & text
 */
async function updateBadgeForActiveTab(stateOverride = null) {
  const state = stateOverride || (await getState());
  try {
    if (!state.enabled) {
      await chrome.action.setBadgeBackgroundColor({ color: '#FF1744' });
      await chrome.action.setBadgeText({ text: 'OFF' });
      return;
    }

    await chrome.action.setBadgeBackgroundColor({ color: '#00C853' });

    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    if (activeTab && activeTab.id) {
      const count = tabBlockCounts.get(activeTab.id) || 0;
      await chrome.action.setBadgeText({
        tabId: activeTab.id,
        text: count > 0 ? (count > 999 ? '999+' : String(count)) : 'ON'
      });
    } else {
      await chrome.action.setBadgeText({ text: 'ON' });
    }
  } catch (_) {
    // Ignore tab query errors during startup
  }
}

/**
 * Record a blocked event & update telemetry
 */
async function recordBlockedEvent({
  tabId,
  domain,
  url,
  category = 'Ad Network',
  bytesEstimate = 18432,
  isYoutubeAd = false,
  isPopunder = false,
  isTracker = false,
  isCosmetic = false
}) {
  const state = await getState();
  if (!state.enabled) return;

  if (tabId && tabId > 0) {
    const prev = tabBlockCounts.get(tabId) || 0;
    const next = prev + 1;
    tabBlockCounts.set(tabId, next);
    try {
      await chrome.action.setBadgeBackgroundColor({ color: '#00C853', tabId });
      await chrome.action.setBadgeText({
        tabId,
        text: next > 999 ? '999+' : String(next)
      });
    } catch (_) {}
  }

  const stats = { ...state.stats };
  stats.totalBlocked = (stats.totalBlocked || 0) + 1;
  stats.bytesSaved = (stats.bytesSaved || 0) + bytesEstimate;

  if (isYoutubeAd) stats.youtubeAdsSkipped = (stats.youtubeAdsSkipped || 0) + 1;
  if (isPopunder) stats.popundersBlocked = (stats.popundersBlocked || 0) + 1;
  if (isTracker) stats.trackersBlocked = (stats.trackersBlocked || 0) + 1;
  if (isCosmetic) stats.cosmeticHidden = (stats.cosmeticHidden || 0) + 1;

  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    timestamp: new Date().toLocaleTimeString(),
    domain: domain || extractHostname(url) || 'unknown.ad.host',
    url: (url || '').slice(0, 160),
    category,
    action: 'BLOCKED'
  };

  const activityLog = [entry, ...(state.activityLog || [])].slice(0, 150);

  await saveState({ stats, activityLog });
}

function extractHostname(url) {
  if (!url) return '';
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch (_) {
    return String(url).split('/')[0];
  }
}

/**
 * Listen to DNR matched rules if declarativeNetRequestFeedback is available
 */
if (
  chrome.declarativeNetRequest &&
  chrome.declarativeNetRequest.onRuleMatchedDebug
) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    const reqUrl = info.request?.url || '';
    const host = extractHostname(reqUrl);
    const rulesetId = info.rule?.rulesetId || '';
    const isTracker = rulesetId === 'ruleset_privacy_trackers';
    const isYoutube =
      host.includes('youtube.com') ||
      host.includes('googlevideo.com') ||
      host.includes('doubleclick.net');

    recordBlockedEvent({
      tabId: info.request?.tabId,
      domain: host,
      url: reqUrl,
      category: isTracker
        ? 'Privacy Tracker'
        : isYoutube
        ? 'YouTube / Video Ad'
        : 'Brave DNR Shield',
      bytesEstimate: isYoutube ? 65536 : 16384,
      isYoutubeAd: isYoutube,
      isTracker
    });
  });
}

/**
 * Always-On Browser Startup Handler:
 * When the user opens the browser, automatically ensure AdBlock Shield Pro is ON
 * if `alwaysOnStartup` is enabled (true by default).
 */
chrome.runtime.onStartup.addListener(async () => {
  const state = await getState();
  if (state.alwaysOnStartup !== false) {
    state.enabled = true;
    await saveState({ enabled: true });
  }
  await syncProtectionEngine(state);
  if (state.autoUpdateEnabled !== false) {
    checkRemoteUpdates(false);
  }
});

/**
 * Extension Install / Update Handler
 */
chrome.runtime.onInstalled.addListener(async (details) => {
  const existing = await chrome.storage.local.get(null);
  const merged = {
    ...DEFAULT_STATE,
    ...existing,
    version: '2.0.1',
    enabled:
      existing.alwaysOnStartup !== false
        ? true
        : existing.enabled ?? DEFAULT_STATE.enabled
  };
  await chrome.storage.local.set(merged);
  await syncProtectionEngine(merged);

  // Set up periodic watchdog & auto-update alarms
  chrome.alarms.create('adblock_shield_watchdog', { periodInMinutes: 1 });
  chrome.alarms.create('adblock_shield_autoupdate', { periodInMinutes: 180 });
});

/**
 * Watchdog & Auto-Update Alarms
 */
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'adblock_shield_watchdog') {
    const state = await getState();
    await updateBadgeForActiveTab(state);
  } else if (alarm.name === 'adblock_shield_autoupdate') {
    const state = await getState();
    if (state.autoUpdateEnabled !== false) {
      await checkRemoteUpdates(false);
    }
  }
});

/**
 * Reset per-tab counter on main_frame navigation
 */
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    tabBlockCounts.set(tabId, 0);
    updateBadgeForActiveTab();
  }
});

chrome.tabs.onActivated.addListener(() => {
  updateBadgeForActiveTab();
});

chrome.tabs.onRemoved.addListener((tabId) => {
  tabBlockCounts.delete(tabId);
});

/**
 * Silent OTA Update Checker
 */
async function checkRemoteUpdates(manual = false) {
  const state = await getState();
  try {
    const response = await fetch(`${OTA_MANIFEST_URL}?t=${Date.now()}`, {
      cache: 'no-store'
    });
    if (response.ok) {
      const data = await response.json();
      const remoteVer = String(
        data.versionName || data.version || '2.0.1'
      ).replace(/^v/i, '');
      const isNewer = compareSemver(remoteVer, state.version) > 0;
      const nowStr = new Date().toLocaleString();
      const buildStamp =
        data.definitionsBuild ||
        new Date().toISOString().slice(0, 16).replace(/[-T:]/g, '.');

      const patch = {
        lastUpdated: nowStr,
        definitionsBuild: buildStamp,
        updateAvailable: isNewer,
        latestRemoteVersion: remoteVer,
        latestReleaseNotes:
          data.releaseNotes ||
          data.changelog ||
          'Synchronized latest Brave Shield DNR rules & YouTube SABR signatures.'
      };
      await saveState(patch);
      await syncProtectionEngine({ ...state, ...patch });
      return { ok: true, ...patch };
    }
  } catch (_) {
    // Fallback if offline
  }

  const nowStr = new Date().toLocaleString();
  await saveState({ lastUpdated: nowStr });
  if (manual) {
    await syncProtectionEngine(state);
  }
  return {
    ok: true,
    updateAvailable: false,
    lastUpdated: nowStr,
    definitionsBuild: state.definitionsBuild
  };
}

function compareSemver(a, b) {
  const pa = String(a)
    .split('.')
    .map((n) => parseInt(n, 10) || 0);
  const pb = String(b)
    .split('.')
    .map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da > db) return 1;
    if (da < db) return -1;
  }
  return 0;
}

/**
 * Message Bus for Popup, Dashboard, and Content Scripts
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    const state = await getState();
    const tabId = sender?.tab?.id || message?.tabId;

    switch (message?.type) {
      case 'GET_STATE': {
        let activeTabCount = 0;
        let activeTabHost = '';
        try {
          const [tab] = await chrome.tabs.query({
            active: true,
            currentWindow: true
          });
          if (tab) {
            activeTabCount = tabBlockCounts.get(tab.id) || 0;
            activeTabHost = extractHostname(tab.url || '');
          }
        } catch (_) {}

        sendResponse({
          ok: true,
          state,
          activeTabCount,
          activeTabHost
        });
        break;
      }

      case 'TOGGLE_SHIELD': {
        const nextEnabled =
          typeof message.enabled === 'boolean'
            ? message.enabled
            : !state.enabled;
        const updated = { ...state, enabled: nextEnabled };
        await saveState({ enabled: nextEnabled });
        await syncProtectionEngine(updated);
        sendResponse({ ok: true, state: updated });
        break;
      }

      case 'SET_ALWAYS_ON_STARTUP': {
        const alwaysOnStartup = Boolean(message.alwaysOnStartup);
        const patch = { alwaysOnStartup };
        if (alwaysOnStartup && !state.enabled) {
          patch.enabled = true;
        }
        const updated = { ...state, ...patch };
        await saveState(patch);
        await syncProtectionEngine(updated);
        sendResponse({ ok: true, state: updated });
        break;
      }

      case 'UPDATE_SETTING': {
        const { key, value } = message;
        if (key && key in DEFAULT_STATE) {
          const updated = { ...state, [key]: value };
          await saveState({ [key]: value });
          await syncProtectionEngine(updated);
          sendResponse({ ok: true, state: updated });
        } else {
          sendResponse({ ok: false });
        }
        break;
      }

      case 'TOGGLE_SITE_WHITELIST': {
        const host = String(message.host || '')
          .trim()
          .toLowerCase()
          .replace(/^www\./, '');
        if (!host) {
          sendResponse({ ok: false });
          break;
        }
        const exists = state.whitelistedSites.includes(host);
        const whitelistedSites = exists
          ? state.whitelistedSites.filter((h) => h !== host)
          : [...state.whitelistedSites, host];
        const updated = { ...state, whitelistedSites };
        await saveState({ whitelistedSites });
        await syncProtectionEngine(updated);
        sendResponse({ ok: true, state: updated, isWhitelisted: !exists });
        break;
      }

      case 'ADD_CUSTOM_DOMAIN': {
        const raw = String(message.domain || '')
          .trim()
          .toLowerCase()
          .replace(/^https?:\/\//, '')
          .replace(/^www\./, '')
          .replace(/\/.*$/, '');
        if (!raw) {
          sendResponse({ ok: false });
          break;
        }
        const customBlockedDomains = Array.from(
          new Set([raw, ...state.customBlockedDomains])
        );
        const updated = { ...state, customBlockedDomains };
        await saveState({ customBlockedDomains });
        await syncProtectionEngine(updated);
        sendResponse({ ok: true, state: updated });
        break;
      }

      case 'REMOVE_CUSTOM_DOMAIN': {
        const target = String(message.domain || '').trim().toLowerCase();
        const customBlockedDomains = state.customBlockedDomains.filter(
          (d) => d !== target
        );
        const updated = { ...state, customBlockedDomains };
        await saveState({ customBlockedDomains });
        await syncProtectionEngine(updated);
        sendResponse({ ok: true, state: updated });
        break;
      }

      case 'CLEAR_ACTIVITY_LOG': {
        await saveState({ activityLog: [] });
        sendResponse({ ok: true, state: { ...state, activityLog: [] } });
        break;
      }

      case 'CHECK_UPDATES': {
        const result = await checkRemoteUpdates(true);
        const freshState = await getState();
        sendResponse({ ok: true, result, state: freshState });
        break;
      }

      case 'CONTENT_BLOCK_EVENT': {
        await recordBlockedEvent({
          tabId,
          domain: message.domain || extractHostname(sender?.tab?.url || ''),
          url: message.url || sender?.tab?.url || '',
          category: message.category || 'Brave Scriptlet',
          bytesEstimate: message.bytesEstimate || 24576,
          isYoutubeAd: Boolean(message.isYoutubeAd),
          isPopunder: Boolean(message.isPopunder),
          isTracker: Boolean(message.isTracker),
          isCosmetic: Boolean(message.isCosmetic)
        });
        sendResponse({ ok: true });
        break;
      }

      default:
        sendResponse({ ok: false, error: 'Unknown message type' });
    }
  })();

  return true; // Async response
});

